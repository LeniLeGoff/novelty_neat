// Automatically generated file by cmake

#include "dart/optimizer/ipopt/IpoptSolver.hpp"
